DOMAIN = 'badnest'
CONF_ISSUE_TOKEN = 'issue_token'
CONF_COOKIE = 'cookie'
